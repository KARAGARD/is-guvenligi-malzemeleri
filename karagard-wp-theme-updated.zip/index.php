<?php get_header(); ?>
<main>
  <h2>Hoş Geldiniz</h2>
  <p>KARAGARD WordPress temasına hoş geldiniz.</p>
</main>
<?php get_footer(); ?>
