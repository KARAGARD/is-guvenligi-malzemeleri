<footer>
  <p>&copy; <?php echo date('Y'); ?> KARAGARD</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
