<?php
// Temel fonksiyonlar
require_once get_template_directory() . '/inc/karagard-functions.php';
